from store.product import Product,Ebook
from store.cart import Cart

Cart()
Product()
Ebook()